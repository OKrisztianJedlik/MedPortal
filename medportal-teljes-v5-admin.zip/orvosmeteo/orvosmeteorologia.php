<?php
require_once 'data.php';
require_once 'header.php';
?>

<section class="py-5">
    <div class="container">
        <div class="mb-4">
            <h1 class="fw-bold text-dark mb-1">Orvosmeteorológiai <span style="color:#00a86b;">Központ</span></h1>
            <p class="text-muted">Válassza ki települését az aktuális fronthatások megtekintéséhez.</p>
        </div>

        <div class="row g-4">
            <?php foreach ($varosok as $slug => $varos): ?>
                <div class="col-md-6 col-lg-3">
                    <a href="reszletek.php?varos=<?= urlencode($slug) ?>" class="card border-0 shadow-sm rounded-4 h-100 text-decoration-none hover-card">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div class="category-icon" style="width:42px;height:42px;"><i class="fas fa-location-dot"></i></div>
                                <span class="badge rounded-pill bg-<?= htmlspecialchars($varos['szin']) ?>">
                                    <?= htmlspecialchars($varos['terheles']) ?>
                                </span>
                            </div>
                            <h5 class="fw-bold text-dark mb-1"><?= htmlspecialchars($varos['nev']) ?></h5>
                            <p class="text-muted small mb-3"><?= htmlspecialchars($varos['front']) ?></p>
                            <div class="d-flex gap-3 pt-2 border-top small text-dark">
                                <span><i class="fas fa-temperature-half text-danger me-1"></i><strong><?= htmlspecialchars($varos['homerseklet']) ?></strong></span>
                                <span><i class="fas fa-tachometer-alt text-success me-1"></i><strong><?= htmlspecialchars($varos['legnyomas']) ?></strong></span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>
