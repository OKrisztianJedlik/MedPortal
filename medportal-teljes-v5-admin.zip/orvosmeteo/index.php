<?php
require_once 'data.php';
require_once 'header.php';
?>

<?php if (isset($_GET['admin_kell'])): ?>
    <div class="alert alert-danger border-0 rounded-0 text-center mb-0 py-2 small fw-semibold">
        <i class="fas fa-lock me-1"></i> Az admin felület megnyitásához jelentkezz be adminisztrátori fiókkal!
    </div>
<?php endif; ?>

<section class="hero-section position-relative d-flex align-items-center">
    <div class="hero-overlay"></div>
    <div class="container position-relative z-2 py-5">
        <div class="hero-green-frame p-4 p-md-5">
            <h1 class="display-4 fw-bold text-white mb-4 lh-sm">
                Keress orvost, fogorvost,<br>állatorvost egyszerűen
            </h1>
            <div class="d-flex flex-wrap gap-3">
                <a href="gyogyszertarak.php" class="btn btn-medgo-green px-4 py-2 fw-bold rounded-1">
                    Gyógyszertárak
                </a>
                <a href="#" data-bs-toggle="modal" data-bs-target="#partnerModal" class="btn btn-medgo-blue px-4 py-2 fw-bold rounded-1">
                    Szerezzen több pácienst a MedGO-val
                </a>
            </div>
        </div>
    </div>
</section>

<section class="search-banner py-5 text-white">
    <div class="container text-center">
        <h2 class="fw-bold mb-4">Mit keres ma?</h2>
        <form action="orvosok.php" method="GET" class="mx-auto" style="max-width: 780px;">
            <div class="input-group input-group-lg bg-white rounded-pill p-1 shadow">
                <span class="input-group-text bg-transparent border-0 text-muted ps-4">
                    <i class="fas fa-magnifying-glass"></i>
                </span>
                <input type="text" name="q" class="form-control border-0 shadow-none fs-6" placeholder="Pl. kardiológus Győr, Dr. Kovács, fogorvos, ügyeletes patika...">
                <button type="submit" class="btn btn-medgo-green rounded-pill px-4 fw-bold">Keresés</button>
            </div>
        </form>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-3">
                <a href="orvosok.php" class="card border-0 shadow-sm rounded-4 h-100 text-decoration-none hover-card p-4 text-center">
                    <div class="category-icon mx-auto mb-3"><i class="fas fa-user-doctor fs-3"></i></div>
                    <h5 class="fw-bold text-dark">Magánorvosok</h5>
                    <p class="text-muted small mb-0">Szakorvosok keresése város és szakterület szerint</p>
                </a>
            </div>
            <div class="col-md-3">
                <a href="gyogyszertarak.php" class="card border-0 shadow-sm rounded-4 h-100 text-decoration-none hover-card p-4 text-center">
                    <div class="category-icon mx-auto mb-3"><i class="fas fa-pills fs-3"></i></div>
                    <h5 class="fw-bold text-dark">Gyógyszertárak</h5>
                    <p class="text-muted small mb-0">Nyitvatartás és ügyeletes patikák listája</p>
                </a>
            </div>
            <div class="col-md-3">
                <a href="orvosmeteorologia.php" class="card border-0 shadow-sm rounded-4 h-100 text-decoration-none hover-card p-4 text-center">
                    <div class="category-icon mx-auto mb-3"><i class="fas fa-cloud-sun fs-3"></i></div>
                    <h5 class="fw-bold text-dark">Orvosmeteorológia</h5>
                    <p class="text-muted small mb-0">Aktuális fronthatások és napi előrejelzés</p>
                </a>
            </div>
            <div class="col-md-3">
                <a href="cikkek.php" class="card border-0 shadow-sm rounded-4 h-100 text-decoration-none hover-card p-4 text-center">
                    <div class="category-icon mx-auto mb-3"><i class="fas fa-newspaper fs-3"></i></div>
                    <h5 class="fw-bold text-dark">Egészség cikkek</h5>
                    <p class="text-muted small mb-0">Orvosi tanácsok és megelőzési útmutatók</p>
                </a>
            </div>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>
