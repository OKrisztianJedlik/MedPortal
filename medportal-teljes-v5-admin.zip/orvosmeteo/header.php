<?php
require_once 'auth.php';
$aktualis_oldal = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedGO – Orvos, fogorvos, gyógyszertár kereső</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="style.css?v=7" rel="stylesheet">
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top py-0">
    <div class="container-fluid px-lg-5">
        <a class="navbar-brand py-2 my-1" href="index.php">
            <span class="brand-badge">MedGO</span>
        </a>

        <button class="navbar-toggler my-2" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-lg-2 fw-semibold small text-uppercase">
                <li class="nav-item">
                    <a class="nav-link px-3 py-3 <?= $aktualis_oldal == 'index.php' ? 'active text-success' : 'text-dark' ?>" href="index.php">Főoldal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 py-3 <?= $aktualis_oldal == 'orvosok.php' ? 'active text-success' : 'text-dark' ?>" href="orvosok.php">Magánorvosok</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 py-3 <?= $aktualis_oldal == 'gyogyszertarak.php' ? 'active text-success' : 'text-dark' ?>" href="gyogyszertarak.php">Gyógyszertárak</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 py-3 <?= $aktualis_oldal == 'orvosmeteorologia.php' ? 'active text-success' : 'text-dark' ?>" href="orvosmeteorologia.php">Orvosmeteorológia</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 py-3 <?= $aktualis_oldal == 'cikkek.php' ? 'active text-success' : 'text-dark' ?>" href="cikkek.php">Cikkek</a>
                </li>
                <?php if (is_admin()): ?>
                    <li class="nav-item">
                        <a class="nav-link px-3 py-3 <?= $aktualis_oldal == 'admin.php' ? 'active text-danger' : 'text-danger' ?>" href="admin.php">
                            <i class="fas fa-shield-halved me-1"></i>Admin
                        </a>
                    </li>
                <?php endif; ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle px-3 py-3 <?= isset($_SESSION['user_email']) ? 'text-success' : 'text-dark' ?>" href="#" role="button" data-bs-toggle="dropdown">
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <i class="fas fa-user-check me-1"></i> <?= htmlspecialchars($_SESSION['user_nev']) ?>
                        <?php else: ?>
                            Fiók
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu border-0 shadow-sm rounded-3">
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <li><span class="dropdown-item-text small text-muted"><?= htmlspecialchars($_SESSION['user_email']) ?></span></li>
                            <?php if (is_admin()): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item py-2 text-danger fw-semibold" href="admin.php"><i class="fas fa-shield-halved me-2"></i>Admin felület</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item py-2 text-dark" href="?logout=1"><i class="fas fa-right-from-bracket me-2"></i>Kijelentkezés</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item py-2" href="#" onclick="openAuthModal('login')"><i class="fas fa-right-to-bracket text-success me-2"></i>Bejelentkezés</a></li>
                            <li><a class="dropdown-item py-2" href="#" onclick="openAuthModal('register')"><i class="fas fa-user-plus text-success me-2"></i>Regisztráció</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <a href="#" data-bs-toggle="modal" data-bs-target="#partnerModal" class="cta-right-btn d-none d-lg-flex align-items-center px-4 text-white text-decoration-none fw-bold small">
        Pácienseket szeretnék <i class="fas fa-arrow-right ms-2"></i>
    </a>
</nav>
