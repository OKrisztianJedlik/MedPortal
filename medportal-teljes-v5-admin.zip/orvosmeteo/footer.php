
<!-- Bejelentkezés és Regisztráció felugró ablak -->
<div class="modal fade" id="loginModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-0 pb-0">
                <ul class="nav nav-tabs border-0 gap-2" id="authTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active fw-bold text-dark" id="login-tab" data-bs-toggle="tab" data-bs-target="#loginPane" type="button">Belépés</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link fw-bold text-dark" id="register-tab" data-bs-toggle="tab" data-bs-target="#registerPane" type="button">Regisztráció</button>
                    </li>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body p-4 tab-content">
                <div class="tab-pane fade show active" id="loginPane">
                    <?php if (!empty($login_hiba)): ?>
                        <div class="alert alert-danger small py-2 mb-3"><?= htmlspecialchars($login_hiba) ?></div>
                    <?php endif; ?>

                    <form method="POST" autocomplete="off">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">E-mail cím</label>
                            <input type="email" name="email" class="form-control" placeholder="admin@medportal.hu" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Jelszó</label>
                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                        </div>
                        <button type="submit" name="login_btn" class="btn btn-medgo-green w-100 py-2 fw-bold">Belépés</button>
                    </form>
                </div>

                <div class="tab-pane fade" id="registerPane">
                    <?php if (!empty($reg_hiba)): ?>
                        <div class="alert alert-danger small py-2 mb-3"><?= htmlspecialchars($reg_hiba) ?></div>
                    <?php endif; ?>

                    <form method="POST" autocomplete="off">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Teljes név</label>
                            <input type="text" name="reg_nev" class="form-control" placeholder="Pl. Kiss Péter" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">E-mail cím</label>
                            <input type="email" name="reg_email" class="form-control" placeholder="barmi@pelda.hu" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Jelszó (min. 4 karakter)</label>
                            <input type="password" name="reg_password" class="form-control" placeholder="••••••••" required>
                        </div>
                        <button type="submit" name="register_btn" class="btn btn-medgo-green w-100 py-2 fw-bold">Fiók létrehozása</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Partner regisztráció ablak -->
<div class="modal fade" id="partnerModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Csatlakozás orvosként / rendelőként</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <p class="text-muted small">Regisztrálja rendelőjét, hogy a páciensek könnyebben megtalálják Önt.</p>
                <form method="POST">
                    <?php if (basename($_SERVER['PHP_SELF']) === 'admin.php'): ?>
                        <input type="hidden" name="from_admin" value="1">
                    <?php endif; ?>
                    <div class="mb-3">
                        <input type="text" name="partner_nev" class="form-control" placeholder="Orvos vagy rendelő neve (pl. Dr. Minta Béla)" required>
                    </div>
                    <div class="mb-3">
                        <input type="text" name="partner_szakterulet" class="form-control" placeholder="Szakterület (pl. Kardiológus)" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-5">
                            <input type="text" name="partner_varos" class="form-control" placeholder="Város (pl. Győr)" required>
                        </div>
                        <div class="col-7">
                            <input type="text" name="partner_cim" class="form-control" placeholder="Rendelő címe" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="text" name="partner_telefon" class="form-control" placeholder="Telefonszám (pl. +36 30 123 4567)" required>
                    </div>
                    <button type="submit" name="partner_btn" class="btn btn-medgo-green w-100 py-2 fw-bold">Mentés</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Orvos szerkesztése felugró ablak (Admin) -->
<div class="modal fade" id="editDocModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-pen-to-square text-primary me-2"></i>Orvos adatainak szerkesztése</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form method="POST">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <input type="hidden" name="from_admin" id="edit_from_admin" value="">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Orvos / rendelő neve</label>
                        <input type="text" name="edit_nev" id="edit_nev" class="form-control" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-8">
                            <label class="form-label small fw-semibold">Szakterület</label>
                            <input type="text" name="edit_szakterulet" id="edit_szakterulet" class="form-control" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Értékelés</label>
                            <input type="text" name="edit_ertekeles" id="edit_ertekeles" class="form-control" placeholder="4.9" required>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-5">
                            <label class="form-label small fw-semibold">Város</label>
                            <input type="text" name="edit_varos" id="edit_varos" class="form-control" required>
                        </div>
                        <div class="col-7">
                            <label class="form-label small fw-semibold">Rendelő címe</label>
                            <input type="text" name="edit_cim" id="edit_cim" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Telefonszám</label>
                        <input type="text" name="edit_telefon" id="edit_telefon" class="form-control" required>
                    </div>
                    <button type="submit" name="edit_doc_btn" class="btn btn-medgo-green w-100 py-2 fw-bold">Változtatások mentése</button>
                </form>
            </div>
        </div>
    </div>
</div>

<footer class="bg-dark text-white-50 py-4 mt-auto">
    <div class="container d-flex flex-wrap justify-content-between align-items-center small">
        <div>
            <span class="brand-badge me-2" style="font-size: 0.9rem; padding: 3px 10px;">MedGO</span>
            &copy; <?= date('Y') ?> Egészségügyi Keresőportál
        </div>
        <div class="d-flex gap-3">
            <a href="index.php" class="text-white-50 text-decoration-none">Főoldal</a>
            <a href="orvosok.php" class="text-white-50 text-decoration-none">Orvosok</a>
            <a href="gyogyszertarak.php" class="text-white-50 text-decoration-none">Gyógyszertárak</a>
            <a href="admin.php" class="text-white-50 text-decoration-none">Admin</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function openAuthModal(tab) {
    const modal = new bootstrap.Modal(document.getElementById('loginModal'));
    modal.show();
    if (tab === 'register') {
        new bootstrap.Tab(document.getElementById('register-tab')).show();
    } else {
        new bootstrap.Tab(document.getElementById('login-tab')).show();
    }
}

function openEditDocModal(btn, fromAdmin = false) {
    document.getElementById('edit_id').value = btn.dataset.id;
    document.getElementById('edit_nev').value = btn.dataset.nev;
    document.getElementById('edit_szakterulet').value = btn.dataset.szakterulet;
    document.getElementById('edit_varos').value = btn.dataset.varos;
    document.getElementById('edit_cim').value = btn.dataset.cim;
    document.getElementById('edit_telefon').value = btn.dataset.telefon;
    document.getElementById('edit_ertekeles').value = btn.dataset.ertekeles;
    const fromInput = document.getElementById('edit_from_admin');
    if (fromAdmin) {
        fromInput.setAttribute('name', 'from_admin');
        fromInput.value = '1';
    } else {
        fromInput.removeAttribute('name');
    }
    new bootstrap.Modal(document.getElementById('editDocModal')).show();
}
</script>

<?php if (!empty($login_hiba) || isset($_GET['admin_kell'])): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() { openAuthModal('login'); });
</script>
<?php elseif (!empty($reg_hiba)): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() { openAuthModal('register'); });
</script>
<?php endif; ?>

</body>
</html>
