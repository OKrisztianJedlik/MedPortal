<?php
require_once 'data.php';

// CSAK ADMIN LÉPHET BE IDE! Ha nem admin, irányítsuk a főoldalra belépési kéréssel
if (!is_admin()) {
    header("Location: index.php?admin_kell=1");
    exit;
}

$admin_hiba = '';
$admin_siker = '';

if (isset($_GET['siker'])) {
    $uzenetek = [
        'user_hozzaadva' => 'Az új felhasználói fiók sikeresen létrejött!',
        'user_torolve' => 'A felhasználó törölve lett a rendszerből.',
        'orvos_hozzaadva' => 'Az új orvos bekerült a listába.',
        'orvos_modositva' => 'Az orvos adatai frissültek.',
        'orvos_torolve' => 'Az orvos törölve lett.',
        'orvosok_visszaallitva' => 'Az alapértelmezett 4 orvos vissza lett állítva.'
    ];
    $admin_siker = $uzenetek[$_GET['siker']] ?? 'Művelet sikeresen végrehajtva.';
}

// ADMIN: ÚJ FELHASZNÁLÓ HOZZÁADÁSA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_add_user'])) {
    $nev = trim($_POST['new_user_nev'] ?? '');
    $email = mb_strtolower(trim($_POST['new_user_email'] ?? ''));
    $jelszo = $_POST['new_user_pass'] ?? '';
    $role = ($_POST['new_user_role'] ?? 'user') === 'admin' ? 'admin' : 'user';

    if ($nev === '' || $email === '' || strlen($jelszo) < 4) {
        $admin_hiba = "Minden mezőt tölts ki (a jelszó legalább 4 karakter legyen)!";
    } elseif (isset($felhasznalok[$email])) {
        $admin_hiba = "Ez az e-mail cím már foglalt!";
    } else {
        $felhasznalok[$email] = [
            'jelszo' => password_hash($jelszo, PASSWORD_DEFAULT),
            'nev' => $nev,
            'role' => $role
        ];
        file_put_contents($users_file, json_encode($felhasznalok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        header("Location: admin.php?siker=user_hozzaadva");
        exit;
    }
}

// ADMIN: FELHASZNÁLÓ TÖRLÉSE
if (isset($_GET['admin_delete_user'])) {
    $torlendo_email = mb_strtolower(trim($_GET['admin_delete_user']));
    if ($torlendo_email === $_SESSION['user_email']) {
        $admin_hiba = "A saját bejelentkezett admin fiókodat nem törölheted!";
    } elseif (isset($felhasznalok[$torlendo_email])) {
        unset($felhasznalok[$torlendo_email]);
        file_put_contents($users_file, json_encode($felhasznalok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        header("Location: admin.php?siker=user_torolve");
        exit;
    }
}

require_once 'header.php';
?>

<section class="py-5">
    <div class="container">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
            <div>
                <span class="badge bg-danger mb-2 px-3 py-1 rounded-pill"><i class="fas fa-shield-halved me-1"></i> ADMINISZTRÁCIÓS FELÜLET</span>
                <h1 class="fw-bold text-dark mb-0">Rendszerkezelő központ</h1>
            </div>
            <div class="text-muted small">
                Bejelentkezve mint: <strong><?= htmlspecialchars($_SESSION['user_nev']) ?></strong> (<?= htmlspecialchars($_SESSION['user_email']) ?>)
            </div>
        </div>

        <?php if ($admin_siker !== ''): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-3 mb-4">
                <i class="fas fa-circle-check me-2"></i> <?= htmlspecialchars($admin_siker) ?>
            </div>
        <?php endif; ?>

        <?php if ($admin_hiba !== ''): ?>
            <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-4">
                <i class="fas fa-triangle-exclamation me-2"></i> <?= htmlspecialchars($admin_hiba) ?>
            </div>
        <?php endif; ?>

        <!-- 1. SZEKCIÓ: FELHASZNÁLÓK KEZELÉSE -->
        <div class="card border-0 shadow-sm rounded-4 mb-5 overflow-hidden">
            <div class="card-header bg-white border-bottom p-4 d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <h4 class="fw-bold text-dark mb-0"><i class="fas fa-users text-success me-2"></i>Regisztrált felhasználók (<?= count($felhasznalok) ?>)</h4>
                    <small class="text-muted">Felhasználók felvétele és törlése kizárólag innen érhető el</small>
                </div>
                <button class="btn btn-medgo-green fw-bold px-4 rounded-pill" data-bs-toggle="modal" data-bs-target="#adminAddUserModal">
                    <i class="fas fa-user-plus me-2"></i>Új felhasználó hozzáadása
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th class="ps-4">Név</th>
                            <th>E-mail cím</th>
                            <th>Jogosultság</th>
                            <th class="text-end pe-4">Művelet</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($felhasznalok as $email => $user): ?>
                            <tr>
                                <td class="ps-4 fw-semibold text-dark"><?= htmlspecialchars($user['nev']) ?></td>
                                <td class="text-muted"><?= htmlspecialchars($email) ?></td>
                                <td>
                                    <?php if (($user['role'] ?? 'user') === 'admin'): ?>
                                        <span class="badge bg-danger rounded-pill px-3">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary bg-opacity-10 text-dark rounded-pill px-3">Páciens</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-4">
                                    <?php if ($email === $_SESSION['user_email']): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success">Jelenlegi munkamenet</span>
                                    <?php else: ?>
                                        <a href="admin.php?admin_delete_user=<?= urlencode($email) ?>"
                                           onclick="return confirm('Biztosan törlöd ezt a felhasználót: <?= htmlspecialchars($email, ENT_QUOTES) ?>?');"
                                           class="btn btn-sm btn-outline-danger rounded-pill px-3">
                                            <i class="fas fa-trash-can me-1"></i>Törlés
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 2. SZEKCIÓ: ORVOSOK KEZELÉSE -->
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-header bg-white border-bottom p-4 d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <h4 class="fw-bold text-dark mb-0"><i class="fas fa-user-doctor text-success me-2"></i>Magánorvosok kezelése (<?= count($orvosok) ?>)</h4>
                    <small class="text-muted">Orvosok szerkesztése, törlése és új rendelő rögzítése</small>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-medgo-green fw-bold px-4 rounded-pill" data-bs-toggle="modal" data-bs-target="#partnerModal">
                        <i class="fas fa-plus me-2"></i>Új orvos
                    </button>
                    <a href="admin.php?reset_docs=1&from_admin=1" onclick="return confirm('Visszaállítod az eredeti 4 alap orvost?');" class="btn btn-outline-secondary rounded-pill px-3">
                        <i class="fas fa-rotate-left me-1"></i>Alaphelyzet
                    </a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th class="ps-4">Orvos neve</th>
                            <th>Szakterület</th>
                            <th>Város / Cím</th>
                            <th>Értékelés</th>
                            <th class="text-end pe-4">Műveletek</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orvosok as $doc): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($doc['nev']) ?></td>
                                <td><span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3"><?= htmlspecialchars($doc['szakterulet']) ?></span></td>
                                <td class="small text-muted"><?= htmlspecialchars($doc['cim']) ?></td>
                                <td class="fw-bold text-warning"><i class="fas fa-star"></i> <?= htmlspecialchars($doc['ertekeles']) ?></td>
                                <td class="text-end pe-4">
                                    <button type="button"
                                        onclick="openEditDocModal(this, true)"
                                        data-id="<?= htmlspecialchars($doc['id']) ?>"
                                        data-nev="<?= htmlspecialchars($doc['nev']) ?>"
                                        data-szakterulet="<?= htmlspecialchars($doc['szakterulet']) ?>"
                                        data-varos="<?= htmlspecialchars($doc['varos']) ?>"
                                        data-cim="<?= htmlspecialchars($doc['cim']) ?>"
                                        data-telefon="<?= htmlspecialchars($doc['telefon']) ?>"
                                        data-ertekeles="<?= htmlspecialchars($doc['ertekeles']) ?>"
                                        class="btn btn-sm btn-outline-primary rounded-pill px-3 me-1">
                                        <i class="fas fa-pen me-1"></i>Szerkesztés
                                    </button>
                                    <a href="admin.php?delete_doc=<?= urlencode($doc['id']) ?>&from_admin=1"
                                       onclick="return confirm('Biztosan törlöd őt: <?= htmlspecialchars($doc['nev'], ENT_QUOTES) ?>?');"
                                       class="btn btn-sm btn-outline-danger rounded-pill px-3">
                                        <i class="fas fa-trash-can me-1"></i>Törlés
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- Admin: Új felhasználó hozzáadása ablak -->
<div class="modal fade" id="adminAddUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-plus text-success me-2"></i>Új felhasználó létrehozása</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form method="POST" autocomplete="off">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Teljes név</label>
                        <input type="text" name="new_user_nev" class="form-control" placeholder="Pl. Nagy Katalin" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">E-mail cím</label>
                        <input type="email" name="new_user_email" class="form-control" placeholder="katalin@pelda.hu" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Jelszó (min. 4 karakter)</label>
                        <input type="password" name="new_user_pass" class="form-control" placeholder="••••••••" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Jogosultság</label>
                        <select name="new_user_role" class="form-select">
                            <option value="user">Páciens (normál felhasználó)</option>
                            <option value="admin">Adminisztrátor</option>
                        </select>
                    </div>
                    <button type="submit" name="admin_add_user" class="btn btn-medgo-green w-100 py-2 fw-bold">Felhasználó mentése</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
