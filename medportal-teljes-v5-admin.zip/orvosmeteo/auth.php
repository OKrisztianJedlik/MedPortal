<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$users_file = __DIR__ . '/users.json';

// Alapértelmezett admin és teszt felhasználó létrehozása, ha még nincs users.json
if (!file_exists($users_file)) {
    $alap_felhasznalok = [
        'admin@medportal.hu' => [
            'jelszo' => password_hash('admin123', PASSWORD_DEFAULT),
            'nev' => 'Főadminisztrátor',
            'role' => 'admin'
        ],
        'teszt@medportal.hu' => [
            'jelszo' => password_hash('123456', PASSWORD_DEFAULT),
            'nev' => 'Teszt Páciens',
            'role' => 'user'
        ]
    ];
    file_put_contents($users_file, json_encode($alap_felhasznalok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$felhasznalok = json_decode(file_get_contents($users_file), true) ?? [];

// Ha az admin@medportal.hu véletlenül törlődne vagy hiányozna a role mező, biztosítjuk az admin jogot
$frissit_users = false;
if (!isset($felhasznalok['admin@medportal.hu'])) {
    $felhasznalok['admin@medportal.hu'] = [
        'jelszo' => password_hash('admin123', PASSWORD_DEFAULT),
        'nev' => 'Főadminisztrátor',
        'role' => 'admin'
    ];
    $frissit_users = true;
}
foreach ($felhasznalok as $mail => &$u) {
    if (empty($u['role'])) {
        $u['role'] = ($mail === 'admin@medportal.hu') ? 'admin' : 'user';
        $frissit_users = true;
    }
}
unset($u);
if ($frissit_users) {
    file_put_contents($users_file, json_encode($felhasznalok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function is_admin(): bool {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

$login_hiba = $_SESSION['flash_login_hiba'] ?? '';
$reg_hiba = $_SESSION['flash_reg_hiba'] ?? '';
unset($_SESSION['flash_login_hiba'], $_SESSION['flash_reg_hiba']);

// 1. NYILVÁNOS REGISZTRÁCIÓ (mindig normál 'user' szerepkörrel)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_btn'])) {
    $nev = trim($_POST['reg_nev'] ?? '');
    $email = mb_strtolower(trim($_POST['reg_email'] ?? ''));
    $jelszo = $_POST['reg_password'] ?? '';

    if ($nev === '' || $email === '' || strlen($jelszo) < 4) {
        $_SESSION['flash_reg_hiba'] = "Minden mezőt tölts ki (a jelszó legalább 4 karakter legyen)!";
    } elseif (isset($felhasznalok[$email])) {
        $_SESSION['flash_reg_hiba'] = "Ezzel az e-mail címmel már regisztráltak!";
    } else {
        $felhasznalok[$email] = [
            'jelszo' => password_hash($jelszo, PASSWORD_DEFAULT),
            'nev' => $nev,
            'role' => 'user'
        ];
        file_put_contents($users_file, json_encode($felhasznalok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $_SESSION['user_email'] = $email;
        $_SESSION['user_nev'] = $nev;
        $_SESSION['user_role'] = 'user';
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// 2. BEJELENTKEZÉS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_btn'])) {
    $email = mb_strtolower(trim($_POST['email'] ?? ''));
    $jelszo = $_POST['password'] ?? '';

    if (isset($felhasznalok[$email]) && password_verify($jelszo, $felhasznalok[$email]['jelszo'])) {
        $_SESSION['user_email'] = $email;
        $_SESSION['user_nev'] = $felhasznalok[$email]['nev'];
        $_SESSION['user_role'] = $felhasznalok[$email]['role'] ?? 'user';
    } else {
        $_SESSION['flash_login_hiba'] = "Hibás e-mail cím vagy jelszó!";
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// 3. KIJELENTKEZÉS
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
