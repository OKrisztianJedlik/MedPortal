<?php
require_once 'data.php';
require_once 'header.php';

$kereses = mb_strtolower(trim($_GET['q'] ?? ''));
$szakterulet = trim($_GET['szakterulet'] ?? '');
?>

<section class="py-5">
    <div class="container">
        <?php if (isset($_GET['uj_orvos'])): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-3 mb-4">
                <i class="fas fa-circle-check me-2"></i> <strong>Sikeres csatlakozás!</strong> Az új orvos/rendelő bekerült a nyilvános listába.
            </div>
        <?php elseif (isset($_GET['szerkesztett_orvos'])): ?>
            <div class="alert alert-info border-0 shadow-sm rounded-3 mb-4">
                <i class="fas fa-pen-to-square me-2"></i> <strong>Sikeres mentés!</strong> Az orvos adatai frissültek.
            </div>
        <?php elseif (isset($_GET['torolt_orvos'])): ?>
            <div class="alert alert-warning border-0 shadow-sm rounded-3 mb-4">
                <i class="fas fa-trash-can me-2"></i> A kiválasztott orvos/rendelő törölve lett a listából.
            </div>
        <?php elseif (isset($_GET['visszaallitva'])): ?>
            <div class="alert alert-secondary border-0 shadow-sm rounded-3 mb-4">
                <i class="fas fa-rotate-left me-2"></i> Az alapértelmezett 4 orvos vissza lett állítva.
            </div>
        <?php endif; ?>

        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
            <div>
                <h1 class="fw-bold text-dark mb-1">Magánorvosok keresése</h1>
                <p class="text-muted mb-0">Válasszon szakembert a listából</p>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <form method="GET" class="d-flex gap-2">
                    <input type="text" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="form-control" placeholder="Név, város vagy szakma...">
                    <button type="submit" class="btn btn-medgo-green px-4 fw-bold">Szűrés</button>
                </form>
                <?php if (is_admin()): ?>
                    <a href="orvosok.php?reset_docs=1" onclick="return confirm('Visszaállítod az eredeti 4 alap orvost?');" class="btn btn-outline-secondary" title="Alap 4 orvos visszaállítása">
                        <i class="fas fa-rotate-left"></i> Alaphelyzet
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="row g-4">
            <?php
            $talalat = false;
            foreach ($orvosok as $orvos):
                $szoveg = mb_strtolower($orvos['nev'] . ' ' . $orvos['szakterulet'] . ' ' . $orvos['varos']);
                if ($kereses !== '' && mb_strpos($szoveg, $kereses) === false) continue;
                if ($szakterulet !== '' && $orvos['szakterulet'] !== $szakterulet) continue;
                $talalat = true;
            ?>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 hover-card">
                        <div class="d-flex justify-content-between align-items-start mb-2 gap-2">
                            <span class="badge bg-success bg-opacity-10 text-success px-3 py-1 rounded-pill fw-semibold">
                                <?= htmlspecialchars($orvos['szakterulet']) ?>
                            </span>
                            <div class="d-flex align-items-center gap-2 flex-wrap justify-content-end">
                                <span class="text-warning fw-bold small me-1">
                                    <i class="fas fa-star"></i> <?= htmlspecialchars($orvos['ertekeles']) ?>
                                </span>
                                <?php if (is_admin()): ?>
                                    <button type="button"
                                        onclick="openEditDocModal(this, false)"
                                        data-id="<?= htmlspecialchars($orvos['id']) ?>"
                                        data-nev="<?= htmlspecialchars($orvos['nev']) ?>"
                                        data-szakterulet="<?= htmlspecialchars($orvos['szakterulet']) ?>"
                                        data-varos="<?= htmlspecialchars($orvos['varos']) ?>"
                                        data-cim="<?= htmlspecialchars($orvos['cim']) ?>"
                                        data-telefon="<?= htmlspecialchars($orvos['telefon']) ?>"
                                        data-ertekeles="<?= htmlspecialchars($orvos['ertekeles']) ?>"
                                        class="btn btn-sm btn-outline-primary rounded-pill px-2 py-0"
                                        title="Adatok szerkesztése">
                                        <i class="fas fa-pen small"></i> Szerkesztés
                                    </button>
                                    <a href="orvosok.php?delete_doc=<?= urlencode($orvos['id']) ?>"
                                       onclick="return confirm('Biztosan törlöd őt a listából: <?= htmlspecialchars($orvos['nev'], ENT_QUOTES) ?>?');"
                                       class="btn btn-sm btn-outline-danger rounded-pill px-2 py-0"
                                       title="Orvos törlése">
                                        <i class="fas fa-trash-can small"></i> Törlés
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <h4 class="fw-bold text-dark mb-1"><?= htmlspecialchars($orvos['nev']) ?></h4>
                        <p class="text-muted small mb-3"><i class="fas fa-location-dot text-success me-1"></i> <?= htmlspecialchars($orvos['cim']) ?></p>
                        <div class="mt-auto pt-3 border-top d-flex justify-content-between align-items-center">
                            <span class="small fw-semibold text-dark"><i class="fas fa-phone text-success me-1"></i> <?= htmlspecialchars($orvos['telefon']) ?></span>
                            <?php if (isset($_SESSION['user_email'])): ?>
                                <button onclick="alert('Sikeres időpontfoglalás (<?= htmlspecialchars($_SESSION['user_nev']) ?>): <?= htmlspecialchars($orvos['nev']) ?>')" class="btn btn-sm btn-medgo-green px-3 rounded-pill fw-bold">Időpontfoglalás</button>
                            <?php else: ?>
                                <button onclick="openAuthModal('login')" class="btn btn-sm btn-outline-success px-3 rounded-pill fw-bold">Belépés foglaláshoz</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!$talalat): ?>
                <div class="col-12 text-center py-5">
                    <p class="text-muted">Nincs találat a megadott keresési feltételekre.</p>
                    <?php if (is_admin()): ?>
                        <a href="orvosok.php?reset_docs=1" class="btn btn-outline-success rounded-pill">Alap orvosok visszaállítása</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>
