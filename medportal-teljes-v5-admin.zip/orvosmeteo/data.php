<?php
require_once 'auth.php';

$orvosok_file = __DIR__ . '/orvosok.json';

$alap_orvosok_sablon = [
    [
        'id' => 'doc_alap_1',
        'nev' => 'Dr. Kovács János',
        'szakterulet' => 'Kardiológus',
        'varos' => 'Győr',
        'cim' => '9021 Győr, Baross Gábor út 14.',
        'telefon' => '+36 96 123 456',
        'ertekeles' => '4.9'
    ],
    [
        'id' => 'doc_alap_2',
        'nev' => 'Dr. Nagy Eszter',
        'szakterulet' => 'Fogorvos',
        'varos' => 'Budapest',
        'cim' => '1052 Budapest, Váci utca 22.',
        'telefon' => '+36 1 987 654',
        'ertekeles' => '4.8'
    ],
    [
        'id' => 'doc_alap_3',
        'nev' => 'Dr. Szabó Péter',
        'szakterulet' => 'Állatorvos',
        'varos' => 'Miskolc',
        'cim' => '3525 Miskolc, Széchenyi utca 40.',
        'telefon' => '+36 46 555 444',
        'ertekeles' => '5.0'
    ],
    [
        'id' => 'doc_alap_4',
        'nev' => 'Dr. Tóth Anna',
        'szakterulet' => 'Bőrgyógyász',
        'varos' => 'Debrecen',
        'cim' => '4024 Debrecen, Piac utca 18.',
        'telefon' => '+36 52 333 222',
        'ertekeles' => '4.7'
    ]
];

if (!file_exists($orvosok_file)) {
    file_put_contents($orvosok_file, json_encode($alap_orvosok_sablon, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$orvosok = json_decode(file_get_contents($orvosok_file), true) ?? [];

$frissiteni_kell = false;
foreach ($orvosok as &$doc) {
    if (empty($doc['id'])) {
        $doc['id'] = uniqid('doc_');
        $frissiteni_kell = true;
    }
}
unset($doc);
if ($frissiteni_kell) {
    file_put_contents($orvosok_file, json_encode($orvosok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// 1. ÚJ ORVOS HOZZÁADÁSA (Partner jelentkezés vagy Admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['partner_btn'])) {
    $nev = trim($_POST['partner_nev'] ?? '');
    $szakterulet = trim($_POST['partner_szakterulet'] ?? '');
    $varos = trim($_POST['partner_varos'] ?? 'Budapest');
    $cim = trim($_POST['partner_cim'] ?? 'Rendelő címe egyeztetés alatt');
    $telefon = trim($_POST['partner_telefon'] ?? '+36 30 000 0000');
    $redirect_admin = isset($_POST['from_admin']) && is_admin();

    if ($nev !== '' && $szakterulet !== '') {
        $orvosok[] = [
            'id' => uniqid('doc_'),
            'nev' => $nev,
            'szakterulet' => $szakterulet,
            'varos' => $varos,
            'cim' => $cim,
            'telefon' => $telefon,
            'ertekeles' => '5.0'
        ];
        file_put_contents($orvosok_file, json_encode($orvosok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        header("Location: " . ($redirect_admin ? "admin.php?siker=orvos_hozzaadva" : "orvosok.php?uj_orvos=1"));
        exit;
    }
}

// 2. ORVOS SZERKESZTÉSE (CSAK ADMIN!)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_doc_btn']) && is_admin()) {
    $edit_id = $_POST['edit_id'] ?? '';
    $nev = trim($_POST['edit_nev'] ?? '');
    $szakterulet = trim($_POST['edit_szakterulet'] ?? '');
    $varos = trim($_POST['edit_varos'] ?? '');
    $cim = trim($_POST['edit_cim'] ?? '');
    $telefon = trim($_POST['edit_telefon'] ?? '');
    $ertekeles = trim($_POST['edit_ertekeles'] ?? '5.0');
    $redirect_admin = isset($_POST['from_admin']);

    if ($edit_id !== '' && $nev !== '' && $szakterulet !== '') {
        foreach ($orvosok as &$doc) {
            if (($doc['id'] ?? '') === $edit_id) {
                $doc['nev'] = $nev;
                $doc['szakterulet'] = $szakterulet;
                $doc['varos'] = $varos;
                $doc['cim'] = $cim;
                $doc['telefon'] = $telefon;
                $doc['ertekeles'] = $ertekeles !== '' ? $ertekeles : '5.0';
                break;
            }
        }
        unset($doc);
        file_put_contents($orvosok_file, json_encode($orvosok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        header("Location: " . ($redirect_admin ? "admin.php?siker=orvos_modositva" : "orvosok.php?szerkesztett_orvos=1"));
        exit;
    }
}

// 3. ORVOS TÖRLÉSE (CSAK ADMIN!)
if (isset($_GET['delete_doc']) && $_GET['delete_doc'] !== '' && is_admin()) {
    $torlendo_id = $_GET['delete_doc'];
    $orvosok = array_values(array_filter($orvosok, function($doc) use ($torlendo_id) {
        return ($doc['id'] ?? '') !== $torlendo_id;
    }));
    file_put_contents($orvosok_file, json_encode($orvosok, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $redirect_admin = isset($_GET['from_admin']);
    header("Location: " . ($redirect_admin ? "admin.php?siker=orvos_torolve" : "orvosok.php?torolt_orvos=1"));
    exit;
}

// 4. ALAP ORVOSOK VISSZAÁLLÍTÁSA (CSAK ADMIN!)
if (isset($_GET['reset_docs']) && is_admin()) {
    file_put_contents($orvosok_file, json_encode($alap_orvosok_sablon, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $redirect_admin = isset($_GET['from_admin']);
    header("Location: " . ($redirect_admin ? "admin.php?siker=orvosok_visszaallitva" : "orvosok.php?visszaallitva=1"));
    exit;
}

$varosok = [
    'ajka' => [
        'nev' => 'Ajka',
        'megye' => 'Veszprém vármegye',
        'terheles' => 'KÖZEPES',
        'szin' => 'warning',
        'homerseklet' => '1°C',
        'legnyomas' => '991 hPa',
        'front' => 'Gyenge hidegfronti hatás',
        'leiras' => 'A reggeli órákban felerősödhetnek a kopásos eredetű ízületi panaszok, valamint fejfájás és vérnyomás-ingadozás is jelentkezhet.',
        'tanacs' => 'Fogyasszon elegendő folyadékot, és kerülje a hirtelen fizikai megterhelést.'
    ],
    'gyor' => [
        'nev' => 'Győr',
        'megye' => 'Győr-Moson-Sopron vármegye',
        'terheles' => 'MAGAS',
        'szin' => 'danger',
        'homerseklet' => '0°C',
        'legnyomas' => '989 hPa',
        'front' => 'Erős hidegfronti hatás',
        'leiras' => 'A hirtelen légnyomásváltozás miatt görcsös panaszok, mellkasi diszkomfort és fokozott ízületi fájdalmak jelentkezhetnek.',
        'tanacs' => 'Szív- és érrendszeri betegek számára fokozott óvatosság és pihenés javasolt.'
    ],
    'miskolc' => [
        'nev' => 'Miskolc',
        'megye' => 'Borsod-Abaúj-Zemplén vármegye',
        'terheles' => 'MAGAS',
        'szin' => 'danger',
        'homerseklet' => '0°C',
        'legnyomas' => '995 hPa',
        'front' => 'Erős hidegfront és páradús levegő',
        'leiras' => 'A nyirkos, hideg idő felerősíti a reumatikus panaszokat, és megterheli a légutakat is.',
        'tanacs' => 'Tartsa melegen az ízületeit, és figyeljen a megfelelő vitaminpótlásra.'
    ],
    'bekescsaba' => [
        'nev' => 'Békéscsaba',
        'megye' => 'Békés vármegye',
        'terheles' => 'ALACSONY',
        'szin' => 'success',
        'homerseklet' => '1°C',
        'legnyomas' => '1011 hPa',
        'front' => 'Frontmentes idő',
        'leiras' => 'Számottevő fronthatás nem terheli a szervezetet, a legtöbb krónikus beteg állapota stabil marad.',
        'tanacs' => 'Ideális időszak szabadtéri mozgáshoz, réteges öltözködés mellett.'
    ]
];

$gyogyszertarak = [
    [
        'nev' => 'Arany Sas Gyógyszertár',
        'varos' => 'Győr',
        'cim' => '9022 Győr, Szent István út 10.',
        'nyitvatartas' => '08:00 - 20:00',
        'ugyeletes' => true
    ],
    [
        'nev' => 'Szent Lélek Patika',
        'varos' => 'Miskolc',
        'cim' => '3530 Miskolc, Bajcsy-Zsilinszky út 5.',
        'nyitvatartas' => '07:30 - 19:00',
        'ugyeletes' => false
    ],
    [
        'nev' => 'Kígyó Gyógyszertár',
        'varos' => 'Budapest',
        'cim' => '1061 Budapest, Andrássy út 32.',
        'nyitvatartas' => '00:00 - 24:00 (Non-stop)',
        'ugyeletes' => true
    ]
];

$cikkek = [
    [
        'cim' => 'Hogyan védekezzünk az erős hidegfront tünetei ellen?',
        'kategoria' => 'Orvosmeteorológia',
        'datum' => '2026. 11. 25.',
        'kivonat' => 'A hirtelen légnyomásesés és lehűlés megterheli a keringést. Mutatjuk a legfontosabb megelőző lépéseket.'
    ],
    [
        'cim' => 'Mikor érdemes évente teljes nagylabor vizsgálatot kérni?',
        'kategoria' => 'Megelőzés',
        'datum' => '2026. 11. 20.',
        'kivonat' => 'A rendszeres vérképellenőrzés segít időben felismerni a rejtett gyulladásokat és vitaminhiányt.'
    ],
    [
        'cim' => 'Ízületi fájdalmak ősszel és télen: természetes megoldások',
        'kategoria' => 'Életmód',
        'datum' => '2026. 11. 15.',
        'kivonat' => 'Miért fájnak jobban a térdek és a derék nyirkos időben, és mit tehetünk ellene otthon?'
    ]
];
?>
