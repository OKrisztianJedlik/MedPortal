<?php
require_once 'data.php';
require_once 'header.php';

$slug = $_GET['varos'] ?? '';
$varos = $varosok[$slug] ?? null;
?>

<section class="py-5">
    <div class="container">
        <?php if ($varos): ?>
            <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4 pb-3 border-bottom">
                    <div>
                        <span class="text-muted small"><?= htmlspecialchars($varos['megye']) ?></span>
                        <h1 class="fw-bold text-dark mb-0"><?= htmlspecialchars($varos['nev']) ?> – Frontjelentés</h1>
                    </div>
                    <span class="badge rounded-pill px-4 py-2 fs-6 bg-<?= htmlspecialchars($varos['szin']) ?>">
                        Terhelés: <?= htmlspecialchars($varos['terheles']) ?>
                    </span>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-4"><div class="p-3 bg-light rounded-3"><strong>Fronthatás:</strong> <?= htmlspecialchars($varos['front']) ?></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded-3"><strong>Hőmérséklet:</strong> <?= htmlspecialchars($varos['homerseklet']) ?></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded-3"><strong>Légnyomás:</strong> <?= htmlspecialchars($varos['legnyomas']) ?></div></div>
                </div>

                <h5 class="fw-bold">Várható tünetek</h5>
                <p class="text-secondary mb-4"><?= htmlspecialchars($varos['leiras']) ?></p>

                <div class="alert alert-success border-0 rounded-3 mb-4">
                    <strong>Orvosi javaslat:</strong> <?= htmlspecialchars($varos['tanacs']) ?>
                </div>

                <div>
                    <a href="orvosmeteorologia.php" class="btn btn-outline-success rounded-pill px-4">
                        <i class="fas fa-arrow-left me-2"></i>Vissza a városokhoz
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">A keresett település nem található.</div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'footer.php'; ?>
