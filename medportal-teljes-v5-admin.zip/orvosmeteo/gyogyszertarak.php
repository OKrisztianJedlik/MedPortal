<?php
require_once 'data.php';
require_once 'header.php';
?>

<section class="py-5">
    <div class="container">
        <h1 class="fw-bold text-dark mb-2">Gyógyszertárak és ügyeletes patikák</h1>
        <p class="text-muted mb-4">Aktuális nyitvatartási idők és elérhetőségek</p>

        <div class="row g-4">
            <?php foreach ($gyogyszertarak as $patika): ?>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 hover-card">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="category-icon" style="width:45px;height:45px;"><i class="fas fa-mortar-pestle"></i></div>
                            <?php if ($patika['ugyeletes']): ?>
                                <span class="badge bg-danger rounded-pill px-3">ÜGYELETES</span>
                            <?php else: ?>
                                <span class="badge bg-secondary rounded-pill px-3">Normál nyitvatartás</span>
                            <?php endif; ?>
                        </div>
                        <h5 class="fw-bold text-dark mb-1"><?= htmlspecialchars($patika['nev']) ?></h5>
                        <p class="text-muted small mb-3"><?= htmlspecialchars($patika['cim']) ?></p>
                        <div class="mt-auto pt-2 border-top small text-dark">
                            <i class="far fa-clock text-success me-1"></i> Nyitva: <strong><?= htmlspecialchars($patika['nyitvatartas']) ?></strong>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>
