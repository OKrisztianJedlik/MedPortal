<?php
require_once 'data.php';
require_once 'header.php';
?>

<section class="py-5">
    <div class="container">
        <h1 class="fw-bold text-dark mb-2">Egészségügyi cikkek és tanácsok</h1>
        <p class="text-muted mb-4">Hasznos olvasnivalók orvosoktól és szakértőktől</p>

        <div class="row g-4">
            <?php foreach ($cikkek as $cikk): ?>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 hover-card">
                        <div class="d-flex justify-content-between align-items-center mb-3 small">
                            <span class="badge bg-success bg-opacity-10 text-success"><?= htmlspecialchars($cikk['kategoria']) ?></span>
                            <span class="text-muted"><?= htmlspecialchars($cikk['datum']) ?></span>
                        </div>
                        <h5 class="fw-bold text-dark mb-3"><?= htmlspecialchars($cikk['cim']) ?></h5>
                        <p class="text-muted small mb-4"><?= htmlspecialchars($cikk['kivonat']) ?></p>
                        <div class="mt-auto">
                            <button onclick="alert('Cikk teljes tartalma hamarosan...')" class="btn btn-sm btn-outline-success rounded-pill px-3">Tovább olvasom</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>
